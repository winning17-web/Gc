from src.models.user import db

class Game(db.Model):
    __tablename__ = 'games'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    slug = db.Column(db.String(50), unique=True, nullable=False)
    description = db.Column(db.Text)
    logo_url = db.Column(db.String(255))
    active = db.Column(db.Boolean, default=True)
    
    # Relationships
    tournaments = db.relationship('Tournament', back_populates='game')
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'slug': self.slug,
            'description': self.description,
            'logo_url': self.logo_url,
            'active': self.active,
            'active_tournaments': len([t for t in self.tournaments if t.status != 'completed'])
        }

