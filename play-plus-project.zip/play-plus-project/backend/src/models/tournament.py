from datetime import datetime
from src.models.user import db

# Association table for tournament participants
tournament_participants = db.Table(
    'tournament_participants',
    db.Column('user_id', db.Integer, db.ForeignKey('users.id'), primary_key=True),
    db.Column('tournament_id', db.Integer, db.ForeignKey('tournaments.id'), primary_key=True),
    db.Column('joined_at', db.DateTime, default=datetime.utcnow)
)

class Tournament(db.Model):
    __tablename__ = 'tournaments'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    game_id = db.Column(db.Integer, db.ForeignKey('games.id'), nullable=False)
    tier = db.Column(db.String(20), nullable=False)
    format = db.Column(db.String(20), nullable=False)  # solo, duo, trio, squad
    start_time = db.Column(db.DateTime, nullable=False)
    entry_fee = db.Column(db.Float, default=0)
    prize_pool = db.Column(db.Float, default=0)
    max_participants = db.Column(db.Integer, default=100)
    status = db.Column(db.String(20), default='upcoming')  # upcoming, live, completed
    winner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    game = db.relationship('Game', back_populates='tournaments')
    participants = db.relationship('User', secondary='tournament_participants', back_populates='tournaments')
    winner = db.relationship('User', foreign_keys=[winner_id])
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'game': self.game.to_dict() if self.game else None,
            'tier': self.tier,
            'format': self.format,
            'start_time': self.start_time.isoformat(),
            'entry_fee': self.entry_fee,
            'prize_pool': self.prize_pool,
            'max_participants': self.max_participants,
            'current_participants': len(self.participants),
            'status': self.status,
            'winner': self.winner.username if self.winner else None,
            'created_at': self.created_at.isoformat()
        }

