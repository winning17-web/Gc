# Import models to make them available
from src.models.user import User, db
from src.models.game import Game
from src.models.tournament import Tournament, tournament_participants

# Initialize models
def init_models(app):
    db.init_app(app)
    with app.app_context():
        db.create_all()

