from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from src.models.game import Game
from src.models.user import db

games_bp = Blueprint('games', __name__)

@games_bp.route('', methods=['GET'])
def get_games():
    games = Game.query.filter_by(active=True).all()
    
    return jsonify({
        'games': [g.to_dict() for g in games]
    }), 200

@games_bp.route('/<string:slug>', methods=['GET'])
def get_game(slug):
    game = Game.query.filter_by(slug=slug).first()
    
    if not game:
        return jsonify({'error': 'Game not found'}), 404
    
    return jsonify(game.to_dict()), 200

@games_bp.route('', methods=['POST'])
@jwt_required()
def create_game():
    data = request.get_json()
    
    # Validate required fields
    if not all(k in data for k in ['name', 'slug', 'description']):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Check if game already exists
    if Game.query.filter_by(slug=data['slug']).first():
        return jsonify({'error': 'Game with this slug already exists'}), 409
    
    # Create game
    game = Game(
        name=data['name'],
        slug=data['slug'],
        description=data['description'],
        logo_url=data.get('logo_url', ''),
        active=data.get('active', True)
    )
    
    db.session.add(game)
    db.session.commit()
    
    return jsonify({
        'message': 'Game created successfully',
        'game': game.to_dict()
    }), 201

