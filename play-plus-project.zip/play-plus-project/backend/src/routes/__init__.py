# Import routes to make them available
from src.routes.auth import auth_bp
from src.routes.tournaments import tournaments_bp
from src.routes.games import games_bp

# Register blueprints
def register_blueprints(app):
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(tournaments_bp, url_prefix='/api/tournaments')
    app.register_blueprint(games_bp, url_prefix='/api/games')

