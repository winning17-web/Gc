from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from src.models.tournament import Tournament, tournament_participants
from src.models.game import Game
from src.models.user import User, db
from datetime import datetime

tournaments_bp = Blueprint('tournaments', __name__)

@tournaments_bp.route('', methods=['GET'])
def get_tournaments():
    status = request.args.get('status', 'all')
    game_slug = request.args.get('game', None)
    
    query = Tournament.query
    
    # Filter by status
    if status != 'all':
        query = query.filter_by(status=status)
    
    # Filter by game
    if game_slug:
        game = Game.query.filter_by(slug=game_slug).first()
        if game:
            query = query.filter_by(game_id=game.id)
    
    # Get tournaments
    tournaments = query.all()
    
    return jsonify({
        'tournaments': [t.to_dict() for t in tournaments]
    }), 200

@tournaments_bp.route('/<int:tournament_id>', methods=['GET'])
def get_tournament(tournament_id):
    tournament = Tournament.query.get(tournament_id)
    
    if not tournament:
        return jsonify({'error': 'Tournament not found'}), 404
    
    return jsonify(tournament.to_dict()), 200

@tournaments_bp.route('', methods=['POST'])
@jwt_required()
def create_tournament():
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['name', 'game_id', 'tier', 'format', 'start_time', 'max_participants']
    if not all(k in data for k in required_fields):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Check if game exists
    game = Game.query.get(data['game_id'])
    if not game:
        return jsonify({'error': 'Game not found'}), 404
    
    # Parse start time
    try:
        start_time = datetime.fromisoformat(data['start_time'])
    except ValueError:
        return jsonify({'error': 'Invalid start time format'}), 400
    
    # Create tournament
    tournament = Tournament(
        name=data['name'],
        game_id=data['game_id'],
        tier=data['tier'],
        format=data['format'],
        start_time=start_time,
        entry_fee=data.get('entry_fee', 0),
        prize_pool=data.get('prize_pool', 0),
        max_participants=data['max_participants'],
        status='upcoming'
    )
    
    db.session.add(tournament)
    db.session.commit()
    
    return jsonify({
        'message': 'Tournament created successfully',
        'tournament': tournament.to_dict()
    }), 201

@tournaments_bp.route('/<int:tournament_id>/join', methods=['POST'])
@jwt_required()
def join_tournament(tournament_id):
    user_id = get_jwt_identity()
    
    # Check if tournament exists
    tournament = Tournament.query.get(tournament_id)
    if not tournament:
        return jsonify({'error': 'Tournament not found'}), 404
    
    # Check if tournament is full
    if len(tournament.participants) >= tournament.max_participants:
        return jsonify({'error': 'Tournament is full'}), 400
    
    # Check if user already joined
    user = User.query.get(user_id)
    if user in tournament.participants:
        return jsonify({'error': 'Already joined this tournament'}), 400
    
    # Join tournament
    tournament.participants.append(user)
    db.session.commit()
    
    return jsonify({
        'message': 'Joined tournament successfully',
        'tournament': tournament.to_dict()
    }), 200

