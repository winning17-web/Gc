from flask import Flask, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager
import os

from src.models import init_models
from src.routes import register_blueprints

# Create Flask app
app = Flask(__name__)

# Configure app
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///play_plus.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY', 'jwt-secret-key')

# Initialize extensions
CORS(app)
jwt = JWTManager(app)

# Initialize models
init_models(app)

# Register blueprints
register_blueprints(app)

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def server_error(error):
    return jsonify({'error': 'Server error'}), 500

# Root route
@app.route('/')
def index():
    return jsonify({
        'name': 'Play+ API',
        'version': '1.0.0',
        'description': 'API for the Play+ mobile gaming tournament platform'
    })

# Run app
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

