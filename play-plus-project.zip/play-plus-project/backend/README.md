# Play+ API

Backend API for the Play+ mobile gaming tournament platform.

## Features

- User authentication and registration
- Tournament management
- Game information
- Status tier system

## Tech Stack

- Flask: Web framework
- SQLAlchemy: ORM for database operations
- JWT: Authentication
- SQLite: Database (can be configured to use other databases)

## Setup

1. Create and activate a virtual environment:

```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Run the application:

```bash
python src/main.py
```

The API will be available at http://localhost:5000

## API Endpoints

### Authentication

- `POST /api/auth/register`: Register a new user
- `POST /api/auth/login`: Login and get access token
- `GET /api/auth/profile`: Get user profile (requires authentication)

### Tournaments

- `GET /api/tournaments`: Get all tournaments
- `GET /api/tournaments/<id>`: Get tournament by ID
- `POST /api/tournaments`: Create a new tournament (requires authentication)
- `POST /api/tournaments/<id>/join`: Join a tournament (requires authentication)

### Games

- `GET /api/games`: Get all games
- `GET /api/games/<slug>`: Get game by slug
- `POST /api/games`: Create a new game (requires authentication)

## Environment Variables

- `SECRET_KEY`: Flask secret key
- `DATABASE_URL`: Database connection URL
- `JWT_SECRET_KEY`: Secret key for JWT

## Deployment

1. Update the requirements.txt file:

```bash
pip freeze > requirements.txt
```

2. Set environment variables for production

3. Use a production WSGI server like Gunicorn

