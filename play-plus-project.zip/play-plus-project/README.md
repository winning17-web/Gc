# Play+ Web Application

Frontend for the Play+ mobile gaming tournament platform.

## Features

- User authentication and registration
- Tournament browsing and participation
- Game information
- Status tier system
- ACE AI system integration

## Tech Stack

- React: Frontend library
- React Router: Navigation
- Tailwind CSS: Styling
- Shadcn UI: UI components
- Lucide Icons: Icon library

## Setup

1. Install dependencies:

```bash
npm install
# or
pnpm install
```

2. Run the development server:

```bash
npm run dev
# or
pnpm run dev
```

The application will be available at http://localhost:5173

## Project Structure

```
play-plus/
├── public/              # Static assets
├── src/
│   ├── assets/          # Images, icons, and other assets
│   ├── components/      # React components
│   │   ├── home/        # Home page components
│   │   ├── layout/      # Layout components
│   │   └── ui/          # UI components
│   ├── hooks/           # Custom React hooks
│   ├── lib/             # Utility functions
│   ├── pages/           # Page components
│   ├── App.css          # Global styles
│   ├── App.jsx          # Main App component
│   └── main.jsx         # Entry point
└── index.html           # HTML entry point
```

## Building for Production

```bash
npm run build
# or
pnpm run build
```

The build output will be in the `dist` directory.

## API Integration

The application is designed to work with the Play+ API. Update the API URL in the configuration if needed.

## Customization

- Update the theme colors in `src/App.css`
- Modify the components in `src/components`
- Add new pages in `src/pages`

