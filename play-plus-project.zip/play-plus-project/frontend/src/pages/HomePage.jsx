import HeroSection from '@/components/home/HeroSection';
import GameSection from '@/components/home/GameSection';
import TournamentSection from '@/components/home/TournamentSection';
import StatusTierSection from '@/components/home/StatusTierSection';
import AceAiSection from '@/components/home/AceAiSection';
import CtaSection from '@/components/home/CtaSection';

export default function HomePage() {
  return (
    <div>
      <HeroSection />
      <GameSection />
      <TournamentSection />
      <StatusTierSection />
      <AceAiSection />
      <CtaSection />
    </div>
  );
}

