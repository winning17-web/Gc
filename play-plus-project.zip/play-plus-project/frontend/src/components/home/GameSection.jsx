import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import codLogo from '@/assets/logos/game-cod.svg';
import fortniteLogo from '@/assets/logos/game-fortnite.svg';
import apexLogo from '@/assets/logos/game-apex.svg';
import pubgLogo from '@/assets/logos/game-pubg.svg';
import freefireLogo from '@/assets/logos/game-freefire.svg';

export default function GameSection() {
  const games = [
    {
      id: 'cod',
      name: 'COD Mobile',
      logo: codLogo,
      description: 'Fast-paced action with multiple game modes',
      activeTournaments: 12,
      players: '5.2K',
      color: 'game-cod-mobile'
    },
    {
      id: 'fortnite',
      name: 'Fortnite',
      logo: fortniteLogo,
      description: 'Build, shoot, and survive in this battle royale',
      activeTournaments: 8,
      players: '4.8K',
      color: 'game-fortnite'
    },
    {
      id: 'apex',
      name: 'Apex Legends',
      logo: apexLogo,
      description: 'Team-based battle royale with unique abilities',
      activeTournaments: 6,
      players: '3.5K',
      color: 'game-apex-legends'
    },
    {
      id: 'pubg',
      name: 'PUBG/BGMI',
      logo: pubgLogo,
      description: 'Tactical survival shooter with realistic gameplay',
      activeTournaments: 10,
      players: '6.1K',
      color: 'game-pubg-bgmi'
    },
    {
      id: 'freefire',
      name: 'Free Fire',
      logo: freefireLogo,
      description: 'Fast-paced battle royale optimized for mobile',
      activeTournaments: 14,
      players: '7.3K',
      color: 'game-free-fire'
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12">
          <div>
            <h2 className="text-3xl font-bold mb-2">Supported Games</h2>
            <p className="text-muted-foreground">Choose your battlefield and dominate the competition</p>
          </div>
          <Button variant="outline" className="mt-4 md:mt-0">
            View All Games
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {games.map((game) => (
            <Link to={`/games/${game.id}`} key={game.id}>
              <div className={`${game.color} bg-card rounded-lg overflow-hidden hover:shadow-lg transition-all duration-300 h-full`}>
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <img src={game.logo} alt={game.name} className="h-12 w-12 mr-4" />
                    <h3 className="text-xl font-bold">{game.name}</h3>
                  </div>
                  <p className="text-muted-foreground mb-6">{game.description}</p>
                  <div className="flex justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground">Active Tournaments</p>
                      <p className="font-bold">{game.activeTournaments}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Active Players</p>
                      <p className="font-bold">{game.players}</p>
                    </div>
                    <Button variant="ghost" size="sm" className="text-primary">
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

