import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowRight, Calendar, Trophy, Users, Clock, DollarSign } from 'lucide-react';
import codLogo from '@/assets/logos/game-cod.svg';
import fortniteLogo from '@/assets/logos/game-fortnite.svg';
import apexLogo from '@/assets/logos/game-apex.svg';
import pubgLogo from '@/assets/logos/game-pubg.svg';
import freefireLogo from '@/assets/logos/game-freefire.svg';

export default function TournamentSection() {
  const [activeTab, setActiveTab] = useState('upcoming');

  const gameLogos = {
    cod: codLogo,
    fortnite: fortniteLogo,
    apex: apexLogo,
    pubg: pubgLogo,
    freefire: freefireLogo
  };

  const tournaments = {
    upcoming: [
      {
        id: 't1',
        name: 'Weekly Cash Cup',
        game: 'fortnite',
        gameId: 'fortnite',
        tier: 'gold',
        format: 'solo',
        startTime: '2025-06-10T18:00:00Z',
        entryFee: 5,
        prizePool: 500,
        participants: 87,
        maxParticipants: 100
      },
      {
        id: 't2',
        name: 'Pro Invitational',
        game: 'Apex Legends',
        gameId: 'apex',
        tier: 'pro',
        format: 'trio',
        startTime: '2025-06-15T19:00:00Z',
        entryFee: 10,
        prizePool: 1000,
        participants: 45,
        maxParticipants: 60
      },
      {
        id: 't3',
        name: 'Bronze Solo Cup',
        game: 'COD Mobile',
        gameId: 'cod',
        tier: 'bronze',
        format: 'solo',
        startTime: '2025-06-07T16:00:00Z',
        entryFee: 1,
        prizePool: 100,
        participants: 65,
        maxParticipants: 100
      },
      {
        id: 't4',
        name: 'PUBG Weekend Showdown',
        game: 'PUBG/BGMI',
        gameId: 'pubg',
        tier: 'silver',
        format: 'squad',
        startTime: '2025-06-08T17:00:00Z',
        entryFee: 2,
        prizePool: 200,
        participants: 72,
        maxParticipants: 100
      }
    ],
    live: [
      {
        id: 't5',
        name: 'Free Fire Cup',
        game: 'Free Fire',
        gameId: 'freefire',
        tier: 'silver',
        format: 'duo',
        startTime: '2025-06-06T15:00:00Z',
        entryFee: 2,
        prizePool: 200,
        participants: 50,
        maxParticipants: 50,
        viewerCount: 1250
      },
      {
        id: 't6',
        name: 'COD Mobile Blitz',
        game: 'COD Mobile',
        gameId: 'cod',
        tier: 'bronze',
        format: 'solo',
        startTime: '2025-06-06T14:30:00Z',
        entryFee: 1,
        prizePool: 100,
        participants: 100,
        maxParticipants: 100,
        viewerCount: 876
      }
    ],
    completed: [
      {
        id: 't7',
        name: 'Fortnite Friday',
        game: 'Fortnite',
        gameId: 'fortnite',
        tier: 'gold',
        format: 'duo',
        startTime: '2025-06-05T18:00:00Z',
        entryFee: 5,
        prizePool: 500,
        participants: 100,
        maxParticipants: 100,
        winner: 'NinjaSlayer'
      },
      {
        id: 't8',
        name: 'Apex Pro League',
        game: 'Apex Legends',
        gameId: 'apex',
        tier: 'pro',
        format: 'trio',
        startTime: '2025-06-04T19:00:00Z',
        entryFee: 10,
        prizePool: 1000,
        participants: 60,
        maxParticipants: 60,
        winner: 'TeamLiquid'
      },
      {
        id: 't9',
        name: 'PUBG Mobile Cup',
        game: 'PUBG/BGMI',
        gameId: 'pubg',
        tier: 'silver',
        format: 'squad',
        startTime: '2025-06-03T17:00:00Z',
        entryFee: 2,
        prizePool: 200,
        participants: 100,
        maxParticipants: 100,
        winner: 'GodSquad'
      },
      {
        id: 't10',
        name: 'Free Fire Challenge',
        game: 'Free Fire',
        gameId: 'freefire',
        tier: 'bronze',
        format: 'solo',
        startTime: '2025-06-02T16:00:00Z',
        entryFee: 1,
        prizePool: 100,
        participants: 50,
        maxParticipants: 50,
        winner: 'FireKing'
      }
    ]
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTierClass = (tier) => {
    switch (tier) {
      case 'bronze': return 'bg-amber-700/20 text-amber-500';
      case 'silver': return 'bg-slate-400/20 text-slate-300';
      case 'gold': return 'bg-yellow-500/20 text-yellow-400';
      case 'pro': return 'bg-purple-500/20 text-purple-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  return (
    <section className="py-16 bg-card/30">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold mb-2">Tournaments</h2>
            <p className="text-muted-foreground">Join competitions and win prizes</p>
          </div>
          <Button variant="outline" className="mt-4 md:mt-0">
            View All Tournaments
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>

        <Tabs defaultValue="upcoming" className="w-full" onValueChange={setActiveTab}>
          <TabsList className="mb-8">
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="live">Live Now</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>
          
          {Object.keys(tournaments).map((tabKey) => (
            <TabsContent key={tabKey} value={tabKey} className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {tournaments[tabKey].map((tournament) => (
                  <Link to={`/tournaments/${tournament.id}`} key={tournament.id}>
                    <div className="tournament-card flex flex-col h-full">
                      {/* Header */}
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center">
                          <img 
                            src={gameLogos[tournament.gameId]} 
                            alt={tournament.game} 
                            className="h-8 w-8 mr-3"
                          />
                          <div>
                            <h3 className="font-bold">{tournament.name}</h3>
                            <p className="text-sm text-muted-foreground">{tournament.game}</p>
                          </div>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-xs font-medium ${getTierClass(tournament.tier)}`}>
                          {tournament.tier.charAt(0).toUpperCase() + tournament.tier.slice(1)}
                        </div>
                      </div>
                      
                      {/* Details */}
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                          <span className="text-sm">{formatDate(tournament.startTime)}</span>
                        </div>
                        <div className="flex items-center">
                          <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                          <span className="text-sm">{tournament.format}</span>
                        </div>
                        <div className="flex items-center">
                          <DollarSign className="h-4 w-4 mr-2 text-muted-foreground" />
                          <span className="text-sm">${tournament.entryFee}</span>
                        </div>
                        <div className="flex items-center">
                          <Trophy className="h-4 w-4 mr-2 text-muted-foreground" />
                          <span className="text-sm">${tournament.prizePool}</span>
                        </div>
                      </div>
                      
                      {/* Status */}
                      <div className="mt-auto">
                        {tabKey === 'upcoming' && (
                          <div className="flex justify-between items-center">
                            <div className="w-full bg-muted rounded-full h-2">
                              <div 
                                className="bg-primary h-2 rounded-full" 
                                style={{ width: `${(tournament.participants / tournament.maxParticipants) * 100}%` }}
                              ></div>
                            </div>
                            <span className="text-sm ml-4 whitespace-nowrap">
                              {tournament.participants}/{tournament.maxParticipants}
                            </span>
                          </div>
                        )}
                        
                        {tabKey === 'live' && (
                          <div className="flex items-center">
                            <div className="h-3 w-3 bg-red-500 rounded-full animate-pulse mr-2"></div>
                            <span className="text-sm text-red-500 font-medium">LIVE</span>
                            <div className="ml-auto flex items-center">
                              <Users className="h-4 w-4 mr-1 text-muted-foreground" />
                              <span className="text-sm">{tournament.viewerCount}</span>
                            </div>
                          </div>
                        )}
                        
                        {tabKey === 'completed' && (
                          <div className="flex items-center">
                            <Trophy className="h-4 w-4 mr-2 text-yellow-500" />
                            <span className="text-sm">Winner: <span className="font-medium">{tournament.winner}</span></span>
                          </div>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  );
}

