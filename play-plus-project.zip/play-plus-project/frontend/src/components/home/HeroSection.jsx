import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import heroBg from '@/assets/images/hero-bg.svg';

export default function HeroSection() {
  return (
    <section 
      className="relative py-20 md:py-32 overflow-hidden"
      style={{
        backgroundImage: `url(${heroBg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
            Compete. Conquer. <br />
            Claim Victory.
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-muted-foreground">
            Join the ultimate mobile gaming tournament platform for COD Mobile, Fortnite, Apex Legends, PUBG/BGMI, and Free Fire.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" className="text-lg">
              Join Now
            </Button>
            <Button size="lg" variant="outline" className="text-lg">
              Browse Tournaments
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
          
          <div className="mt-12 flex flex-wrap gap-8">
            <div className="flex items-center">
              <div className="bg-primary rounded-full h-12 w-12 flex items-center justify-center mr-4">
                <span className="text-xl font-bold">5</span>
              </div>
              <div>
                <h3 className="font-bold">Games</h3>
                <p className="text-sm text-muted-foreground">Supported platforms</p>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="bg-primary rounded-full h-12 w-12 flex items-center justify-center mr-4">
                <span className="text-xl font-bold">24/7</span>
              </div>
              <div>
                <h3 className="font-bold">Tournaments</h3>
                <p className="text-sm text-muted-foreground">Always available</p>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="bg-primary rounded-full h-12 w-12 flex items-center justify-center mr-4">
                <span className="text-xl font-bold">AI</span>
              </div>
              <div>
                <h3 className="font-bold">ACE System</h3>
                <p className="text-sm text-muted-foreground">Advanced matchmaking</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute bottom-0 right-0 w-1/3 h-1/3 bg-gradient-to-tl from-primary/20 to-transparent rounded-full blur-3xl"></div>
      <div className="absolute top-1/4 right-1/4 w-1/4 h-1/4 bg-gradient-to-bl from-secondary/20 to-transparent rounded-full blur-3xl"></div>
    </section>
  );
}

