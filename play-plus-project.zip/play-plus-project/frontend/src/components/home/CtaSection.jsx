import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

export default function CtaSection() {
  return (
    <section className="py-20 bg-primary/10 relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Join the Competition?</h2>
          <p className="text-xl text-muted-foreground mb-8">
            Create your account now and start competing in tournaments across five popular mobile games.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" className="text-lg">
              Sign Up Now
            </Button>
            <Button size="lg" variant="outline" className="text-lg">
              Browse Tournaments
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
          
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-card/50 backdrop-blur-sm rounded-lg p-6">
              <div className="text-3xl font-bold text-primary mb-2">24/7</div>
              <h3 className="font-bold mb-2">Tournaments</h3>
              <p className="text-sm text-muted-foreground">
                Tournaments available around the clock for all skill levels.
              </p>
            </div>
            
            <div className="bg-card/50 backdrop-blur-sm rounded-lg p-6">
              <div className="text-3xl font-bold text-primary mb-2">5</div>
              <h3 className="font-bold mb-2">Games</h3>
              <p className="text-sm text-muted-foreground">
                Support for the most popular mobile battle royale games.
              </p>
            </div>
            
            <div className="bg-card/50 backdrop-blur-sm rounded-lg p-6">
              <div className="text-3xl font-bold text-primary mb-2">$$$</div>
              <h3 className="font-bold mb-2">Prize Pools</h3>
              <p className="text-sm text-muted-foreground">
                Compete for cash prizes across various tournament tiers.
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-1/4 left-1/4 w-1/3 h-1/3 bg-primary/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-1/3 h-1/3 bg-secondary/5 rounded-full blur-3xl"></div>
      </div>
    </section>
  );
}

