import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

export default function StatusTierSection() {
  const tiers = [
    {
      name: 'Rookie',
      description: 'New users and casual participants',
      benefits: ['Basic profile badge', 'Tournament participation'],
      color: 'from-zinc-500 to-zinc-600'
    },
    {
      name: 'Contender',
      description: 'Regular participants developing skills',
      benefits: ['Contender profile badge', '5% reduction on tournament entry fees'],
      color: 'from-blue-500 to-blue-600'
    },
    {
      name: 'Challenger',
      description: 'Experienced players with consistent participation',
      benefits: ['Challenger profile badge', '10% reduction on tournament entry fees', '5% bonus on tournament rewards'],
      color: 'from-green-500 to-green-600'
    },
    {
      name: 'Elite',
      description: 'Skilled players who regularly place well',
      benefits: ['Elite profile badge', '15% reduction on tournament entry fees', '10% bonus on tournament rewards'],
      color: 'from-yellow-500 to-yellow-600'
    },
    {
      name: 'Master',
      description: 'Highly skilled players with significant success',
      benefits: ['Master profile badge', '20% reduction on tournament entry fees', '15% bonus on tournament rewards'],
      color: 'from-purple-500 to-purple-600'
    },
    {
      name: 'Grandmaster',
      description: 'Expert players with exceptional records',
      benefits: ['Grandmaster profile badge', '25% reduction on tournament entry fees', '20% bonus on tournament rewards'],
      color: 'from-red-500 to-red-600'
    },
    {
      name: 'Legend',
      description: 'The most accomplished players on the platform',
      benefits: ['Legend profile badge', '30% reduction on tournament entry fees', '25% bonus on tournament rewards'],
      color: 'from-purple-500 via-red-500 to-yellow-500'
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12">
          <div>
            <h2 className="text-3xl font-bold mb-2">Status Tier System</h2>
            <p className="text-muted-foreground">Progress through tiers and unlock exclusive benefits</p>
          </div>
          <Button variant="outline" className="mt-4 md:mt-0">
            Learn More
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {tiers.map((tier, index) => (
            <div key={tier.name} className="bg-card rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-all duration-300">
              <div className={`h-2 bg-gradient-to-r ${tier.color}`}></div>
              <div className="p-6">
                <div className="flex items-center mb-4">
                  <div className={`tier-badge bg-gradient-to-r ${tier.color} mr-3`}>
                    {index + 1}
                  </div>
                  <h3 className="text-xl font-bold">{tier.name}</h3>
                </div>
                <p className="text-muted-foreground mb-4">{tier.description}</p>
                <h4 className="text-sm font-semibold mb-2">Benefits:</h4>
                <ul className="text-sm text-muted-foreground space-y-1 mb-4">
                  {tier.benefits.map((benefit, i) => (
                    <li key={i} className="flex items-start">
                      <span className="text-primary mr-2">•</span>
                      <span>{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-card rounded-lg p-6 border border-border">
          <h3 className="text-xl font-bold mb-4">How to Progress</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex flex-col">
              <div className="bg-primary/20 rounded-full h-12 w-12 flex items-center justify-center mb-4">
                <span className="text-xl font-bold">1</span>
              </div>
              <h4 className="font-bold mb-2">Participate in Tournaments</h4>
              <p className="text-sm text-muted-foreground">Earn Tier Points (TP) by joining and competing in tournaments across all supported games.</p>
            </div>
            
            <div className="flex flex-col">
              <div className="bg-primary/20 rounded-full h-12 w-12 flex items-center justify-center mb-4">
                <span className="text-xl font-bold">2</span>
              </div>
              <h4 className="font-bold mb-2">Win Matches and Place Well</h4>
              <p className="text-sm text-muted-foreground">Earn more TP by winning tournaments, securing top placements, and eliminating opponents.</p>
            </div>
            
            <div className="flex flex-col">
              <div className="bg-primary/20 rounded-full h-12 w-12 flex items-center justify-center mb-4">
                <span className="text-xl font-bold">3</span>
              </div>
              <h4 className="font-bold mb-2">Stay Active</h4>
              <p className="text-sm text-muted-foreground">Earn bonus TP for daily logins, weekly play, and monthly consistency in participation.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

