import { Button } from '@/components/ui/button';
import { 
  Brain, 
  Shield, 
  Lightbulb, 
  BarChart, 
  Users, 
  Video, 
  MessageSquare, 
  DollarSign 
} from 'lucide-react';

export default function AceAiSection() {
  const features = [
    {
      icon: <Brain className="h-6 w-6" />,
      title: 'Matchmaking System',
      description: 'Creates balanced matches based on player skill levels for fair competition.'
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: 'Fraud Detection',
      description: 'Identifies potential cheating and suspicious behavior to maintain integrity.'
    },
    {
      icon: <Lightbulb className="h-6 w-6" />,
      title: 'Recommendation Engine',
      description: 'Suggests tournaments based on your preferences and play history.'
    },
    {
      icon: <BarChart className="h-6 w-6" />,
      title: 'Tournament Scaling',
      description: 'Ensures 24/7 tournament availability with dynamic scheduling.'
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: 'Player Retention',
      description: 'Identifies players at risk of churning and provides personalized strategies.'
    },
    {
      icon: <Video className="h-6 w-6" />,
      title: 'Livestreaming Enhancement',
      description: 'Generates automated highlights and provides real-time statistics.'
    },
    {
      icon: <MessageSquare className="h-6 w-6" />,
      title: 'Community Management',
      description: 'Moderates chat and community content for a positive environment.'
    },
    {
      icon: <DollarSign className="h-6 w-6" />,
      title: 'Prize Pool Optimization',
      description: 'Dynamically adjusts prize pools based on tournament metrics.'
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-b from-background to-card/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">ACE AI System</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            The Advanced Competition Engine (ACE) is our proprietary AI system that powers the platform, 
            providing intelligent matchmaking, fraud detection, personalized recommendations, and more.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-card rounded-lg p-6 border border-border hover:border-primary/50 transition-all duration-300"
            >
              <div className="bg-primary/10 rounded-lg p-3 inline-block mb-4 text-primary">
                {feature.icon}
              </div>
              <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-card rounded-lg p-8 border border-border relative overflow-hidden">
          <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-primary/10 to-transparent"></div>
          <div className="relative z-10 max-w-2xl">
            <h3 className="text-2xl font-bold mb-4">Experience the Power of AI</h3>
            <p className="text-muted-foreground mb-6">
              Our ACE AI system continuously learns and improves based on user interactions and tournament outcomes, 
              delivering increasingly personalized and optimized experiences for players, organizers, and viewers.
            </p>
            <Button>Learn More About ACE</Button>
          </div>
        </div>
      </div>
    </section>
  );
}

