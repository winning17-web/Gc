import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  Trophy, 
  Users, 
  BarChart, 
  Settings, 
  ChevronLeft,
  ChevronRight,
  Home
} from 'lucide-react';
import codLogo from '@/assets/logos/game-cod.svg';
import fortniteLogo from '@/assets/logos/game-fortnite.svg';
import apexLogo from '@/assets/logos/game-apex.svg';
import pubgLogo from '@/assets/logos/game-pubg.svg';
import freefireLogo from '@/assets/logos/game-freefire.svg';

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  const isActive = (path) => {
    return location.pathname === path;
  };

  const games = [
    { id: 'cod', name: 'COD Mobile', logo: codLogo, path: '/games/cod' },
    { id: 'fortnite', name: 'Fortnite', logo: fortniteLogo, path: '/games/fortnite' },
    { id: 'apex', name: 'Apex Legends', logo: apexLogo, path: '/games/apex' },
    { id: 'pubg', name: 'PUBG/BGMI', logo: pubgLogo, path: '/games/pubg' },
    { id: 'freefire', name: 'Free Fire', logo: freefireLogo, path: '/games/freefire' },
  ];

  return (
    <aside className={`sidebar relative transition-all duration-300 ${collapsed ? 'sidebar-collapsed' : ''}`}>
      {/* Toggle Button */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute -right-3 top-6 h-6 w-6 rounded-full bg-primary text-primary-foreground shadow-md"
        onClick={() => setCollapsed(!collapsed)}
      >
        {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
      </Button>

      {/* Sidebar Content */}
      <div className="flex flex-col h-full p-4">
        {/* Main Navigation */}
        <nav className="space-y-2 mb-6">
          <Link to="/">
            <Button
              variant={isActive('/') ? 'default' : 'ghost'}
              className={`w-full justify-start ${isActive('/') ? 'bg-sidebar-primary text-sidebar-primary-foreground' : ''}`}
            >
              <Home className="h-5 w-5 mr-2" />
              {!collapsed && <span>Home</span>}
            </Button>
          </Link>
          <Link to="/tournaments">
            <Button
              variant={isActive('/tournaments') ? 'default' : 'ghost'}
              className={`w-full justify-start ${isActive('/tournaments') ? 'bg-sidebar-primary text-sidebar-primary-foreground' : ''}`}
            >
              <Trophy className="h-5 w-5 mr-2" />
              {!collapsed && <span>Tournaments</span>}
            </Button>
          </Link>
          <Link to="/leaderboards">
            <Button
              variant={isActive('/leaderboards') ? 'default' : 'ghost'}
              className={`w-full justify-start ${isActive('/leaderboards') ? 'bg-sidebar-primary text-sidebar-primary-foreground' : ''}`}
            >
              <BarChart className="h-5 w-5 mr-2" />
              {!collapsed && <span>Leaderboards</span>}
            </Button>
          </Link>
          <Link to="/community">
            <Button
              variant={isActive('/community') ? 'default' : 'ghost'}
              className={`w-full justify-start ${isActive('/community') ? 'bg-sidebar-primary text-sidebar-primary-foreground' : ''}`}
            >
              <Users className="h-5 w-5 mr-2" />
              {!collapsed && <span>Community</span>}
            </Button>
          </Link>
        </nav>

        {/* Games Section */}
        {!collapsed && <h3 className="text-sm font-semibold text-muted-foreground mb-2">Games</h3>}
        <nav className="space-y-1 mb-6">
          {games.map((game) => (
            <Link to={game.path} key={game.id}>
              <Button
                variant={isActive(game.path) ? 'default' : 'ghost'}
                className={`w-full justify-start ${isActive(game.path) ? 'bg-sidebar-primary text-sidebar-primary-foreground' : ''}`}
              >
                <img src={game.logo} alt={game.name} className="h-5 w-5 mr-2" />
                {!collapsed && <span>{game.name}</span>}
              </Button>
            </Link>
          ))}
        </nav>

        {/* Settings */}
        <div className="mt-auto">
          <Link to="/settings">
            <Button
              variant={isActive('/settings') ? 'default' : 'ghost'}
              className={`w-full justify-start ${isActive('/settings') ? 'bg-sidebar-primary text-sidebar-primary-foreground' : ''}`}
            >
              <Settings className="h-5 w-5 mr-2" />
              {!collapsed && <span>Settings</span>}
            </Button>
          </Link>
        </div>
      </div>
    </aside>
  );
}

