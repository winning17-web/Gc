import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Search, 
  Bell, 
  Menu, 
  X, 
  User,
  LogIn
} from 'lucide-react';
import PlayPlusLogo from '@/assets/logos/play-plus-logo.svg';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false); // For demo purposes

  return (
    <header className="header">
      <div className="container mx-auto flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <img src={PlayPlusLogo} alt="Play+ Logo" className="h-8" />
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <Link to="/tournaments" className="text-foreground hover:text-primary transition-colors">
            Tournaments
          </Link>
          <Link to="/games" className="text-foreground hover:text-primary transition-colors">
            Games
          </Link>
          <Link to="/leaderboards" className="text-foreground hover:text-primary transition-colors">
            Leaderboards
          </Link>
          <Link to="/about" className="text-foreground hover:text-primary transition-colors">
            About
          </Link>
        </nav>

        {/* Search Bar */}
        <div className="hidden md:flex items-center relative flex-1 max-w-xs mx-4">
          <Search className="absolute left-2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search tournaments..."
            className="pl-8 bg-muted/50"
          />
        </div>

        {/* User Actions */}
        <div className="hidden md:flex items-center space-x-4">
          {isLoggedIn ? (
            <>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-destructive"></span>
              </Button>
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
              </Button>
            </>
          ) : (
            <>
              <Button variant="ghost" onClick={() => setIsLoggedIn(true)}>
                <LogIn className="h-5 w-5 mr-2" />
                Login
              </Button>
              <Button>Sign Up</Button>
            </>
          )}
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden flex items-center">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 bg-card border-b border-border z-50 p-4">
          <div className="flex items-center relative mb-4">
            <Search className="absolute left-2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search tournaments..."
              className="pl-8 bg-muted/50"
            />
          </div>
          <nav className="flex flex-col space-y-4">
            <Link 
              to="/tournaments" 
              className="text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Tournaments
            </Link>
            <Link 
              to="/games" 
              className="text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Games
            </Link>
            <Link 
              to="/leaderboards" 
              className="text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              Leaderboards
            </Link>
            <Link 
              to="/about" 
              className="text-foreground hover:text-primary transition-colors"
              onClick={() => setMobileMenuOpen(false)}
            >
              About
            </Link>
            {isLoggedIn ? (
              <div className="flex space-x-4 pt-2 border-t border-border">
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="h-5 w-5" />
                  <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-destructive"></span>
                </Button>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                </Button>
              </div>
            ) : (
              <div className="flex flex-col space-y-2 pt-2 border-t border-border">
                <Button variant="outline" onClick={() => setIsLoggedIn(true)}>
                  <LogIn className="h-5 w-5 mr-2" />
                  Login
                </Button>
                <Button>Sign Up</Button>
              </div>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}

