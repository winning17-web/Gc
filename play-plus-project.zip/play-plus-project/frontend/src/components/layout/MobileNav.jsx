import { Link, useLocation } from 'react-router-dom';
import { Home, Trophy, BarChart, User, Menu } from 'lucide-react';

export default function MobileNav() {
  const location = useLocation();

  const isActive = (path) => {
    return location.pathname === path;
  };

  return (
    <nav className="mobile-nav">
      <Link to="/" className={`mobile-nav-item ${isActive('/') ? 'active' : ''}`}>
        <Home className="h-6 w-6" />
        <span>Home</span>
      </Link>
      <Link to="/tournaments" className={`mobile-nav-item ${isActive('/tournaments') ? 'active' : ''}`}>
        <Trophy className="h-6 w-6" />
        <span>Tournaments</span>
      </Link>
      <Link to="/leaderboards" className={`mobile-nav-item ${isActive('/leaderboards') ? 'active' : ''}`}>
        <BarChart className="h-6 w-6" />
        <span>Leaderboards</span>
      </Link>
      <Link to="/profile" className={`mobile-nav-item ${isActive('/profile') ? 'active' : ''}`}>
        <User className="h-6 w-6" />
        <span>Profile</span>
      </Link>
      <Link to="/menu" className={`mobile-nav-item ${isActive('/menu') ? 'active' : ''}`}>
        <Menu className="h-6 w-6" />
        <span>More</span>
      </Link>
    </nav>
  );
}

